// Stats interfaces
interface OffenseStats {
  gamesPlayed?: number
  goals?: number
  assists?: number
  points?: number
  plusMinus?: number
  pim?: number
  ppg?: number
  shg?: number
}

interface DefenseStats extends OffenseStats {
  hits?: number
  blocks?: number
}

interface GoalieStats {
  gamesPlayed?: number
  wins?: number
  losses?: number
  otl?: number
  gaa?: number
  savePercentage?: number
  shutouts?: number
}

interface TeamStats {
  wins?: number
  losses?: number
  otl?: number
  points?: number
  goalsFor?: number
  goalsAgainst?: number
}

// Fetch stats based on type
export async function fetchStats(type = "offense", teamId?: string) {
  try {
    let url = `/api/stats?type=${type}`
    if (teamId) {
      url += `&teamId=${teamId}`
    }

    const response = await fetch(url)
    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error fetching stats:", error)
    return { data: [] }
  }
}

// Fetch standings
export async function fetchStandings(conference?: string, division?: string) {
  try {
    let url = "/api/standings"
    const params = new URLSearchParams()

    if (conference) {
      params.append("conference", conference)
    }
    if (division) {
      params.append("division", division)
    }

    if (params.toString()) {
      url += `?${params.toString()}`
    }

    const response = await fetch(url)
    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error fetching standings:", error)
    return { data: [] }
  }
}

// Update player stats
export async function updatePlayerStats(playerId: string, stats: OffenseStats | DefenseStats | GoalieStats) {
  try {
    const response = await fetch("/api/stats", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ playerId, stats }),
    })

    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error updating stats:", error)
    return { success: false, message: "Failed to update stats" }
  }
}

// Update team standings
export async function updateTeamStats(teamId: string, stats: TeamStats) {
  try {
    const response = await fetch("/api/standings", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ teamId, stats }),
    })

    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error updating standings:", error)
    return { success: false, message: "Failed to update standings" }
  }
}

// Fetch teams
export async function fetchTeams(includeRoster = false, conference?: string, division?: string) {
  try {
    let url = "/api/teams"
    const params = new URLSearchParams()

    if (includeRoster) {
      params.append("includeRoster", "true")
    }
    if (conference) {
      params.append("conference", conference)
    }
    if (division) {
      params.append("division", division)
    }

    if (params.toString()) {
      url += `?${params.toString()}`
    }

    const response = await fetch(url)
    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error fetching teams:", error)
    return { data: [] }
  }
}

// Fetch team details
export async function fetchTeamDetails(teamId: string) {
  try {
    const response = await fetch(`/api/teams/${teamId}`)
    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error fetching team details:", error)
    return { data: null }
  }
}

// Fetch games
export async function fetchGames(teamId?: string, season?: number, status?: string) {
  try {
    let url = "/api/games"
    const params = new URLSearchParams()

    if (teamId) {
      params.append("teamId", teamId)
    }
    if (season) {
      params.append("season", season.toString())
    }
    if (status) {
      params.append("status", status)
    }

    if (params.toString()) {
      url += `?${params.toString()}`
    }

    const response = await fetch(url)
    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error fetching games:", error)
    return { data: [] }
  }
}

// Create a new game
export async function createGame(homeTeamId: string, awayTeamId: string, date: Date, season: number) {
  try {
    const response = await fetch("/api/games", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ homeTeamId, awayTeamId, date, season }),
    })

    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error creating game:", error)
    return { success: false, message: "Failed to create game" }
  }
}

// Add player to team
export async function addPlayerToTeam(teamId: string, userId: string, role: string) {
  try {
    const response = await fetch(`/api/teams/${teamId}/roster`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ userId, role }),
    })

    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error adding player to team:", error)
    return { success: false, message: "Failed to add player to team" }
  }
}
