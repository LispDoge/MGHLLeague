// This file integrates with the GitHub repo: https://github.com/bg9m9r/tcl-matches.git
// It provides functions to interact with the API for tracking stats and standings

import prisma from "@/lib/prisma"

interface PlayerGameStats {
  playerId: string
  goals: number
  assists: number
  plusMinus: number
  pim: number
  shots: number
  hits: number
  blocks: number
}

interface GameResult {
  gameId: string
  homeScore: number
  awayScore: number
  overtime: boolean
  playerStats: PlayerGameStats[]
}

// Submit game results and update all related stats
export async function submitGameResults(gameResult: GameResult) {
  try {
    const response = await fetch("/api/integration/tcl-matches", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(gameResult),
    })

    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error submitting game results:", error)
    return { success: false, message: "Failed to submit game results" }
  }
}

// Create a new game
export async function scheduleGame(homeTeamId: string, awayTeamId: string, date: Date, season: number) {
  try {
    const response = await fetch("/api/games", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ homeTeamId, awayTeamId, date, season }),
    })

    if (!response.ok) {
      throw new Error(`Error: ${response.status}`)
    }

    return await response.json()
  } catch (error) {
    console.error("Error scheduling game:", error)
    return { success: false, message: "Failed to schedule game" }
  }
}

// Get player stats
export async function getPlayerStats(userId: string) {
  try {
    const playerStats = await prisma.playerStats.findUnique({
      where: { userId },
    })

    return playerStats
  } catch (error) {
    console.error("Error fetching player stats:", error)
    return null
  }
}

// Get team stats
export async function getTeamStats(teamId: string) {
  try {
    const team = await prisma.team.findUnique({
      where: { id: teamId },
    })

    return team
  } catch (error) {
    console.error("Error fetching team stats:", error)
    return null
  }
}

// Get game stats
export async function getGameStats(gameId: string) {
  try {
    const game = await prisma.game.findUnique({
      where: { id: gameId },
      include: {
        homeTeam: true,
        awayTeam: true,
        gameStats: true,
      },
    })

    return game
  } catch (error) {
    console.error("Error fetching game stats:", error)
    return null
  }
}

// Get player game stats
export async function getPlayerGameStats(gameId: string, playerId: string) {
  try {
    const gameStat = await prisma.gameStat.findUnique({
      where: {
        gameId_playerId: {
          gameId,
          playerId,
        },
      },
    })

    return gameStat
  } catch (error) {
    console.error("Error fetching player game stats:", error)
    return null
  }
}
