import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { getToken } from "next-auth/jwt"

// This middleware protects routes that require authentication
export async function middleware(request: NextRequest) {
  const token = await getToken({ req: request })

  // Check if the user is authenticated
  if (!token) {
    // Redirect to login page if not authenticated
    const url = new URL("/login", request.url)
    url.searchParams.set("callbackUrl", request.nextUrl.pathname)
    return NextResponse.redirect(url)
  }

  // Check for admin routes
  if (request.nextUrl.pathname.startsWith("/admin") && token.role !== "admin") {
    // Redirect to dashboard if not an admin
    return NextResponse.redirect(new URL("/dashboard", request.url))
  }

  // Check for team management routes
  if (
    request.nextUrl.pathname.startsWith("/team-management") &&
    token.role !== "admin" &&
    token.role !== "owner" &&
    token.role !== "gm"
  ) {
    // Redirect to dashboard if not authorized
    return NextResponse.redirect(new URL("/dashboard", request.url))
  }

  return NextResponse.next()
}

// Configure which routes use this middleware
export const config = {
  matcher: ["/dashboard/:path*", "/admin/:path*", "/team-management/:path*"],
}
