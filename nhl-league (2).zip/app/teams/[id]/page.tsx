"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Users, Calendar, BarChart3 } from "lucide-react"
import Image from "next/image"
import { fetchTeamDetails, fetchGames } from "@/lib/api-utils"
import { useParams } from "next/navigation"

interface TeamMember {
  id: string
  role: string
  user: {
    id: string
    name: string
    image: string | null
    playerStats: {
      position: string
      gamesPlayed: number
      goals: number
      assists: number
      points: number
      plusMinus: number
    } | null
  }
}

interface Team {
  id: string
  name: string
  abbreviation: string
  logo: string | null
  conference: string
  division: string
  wins: number
  losses: number
  otl: number
  points: number
  goalsFor: number
  goalsAgainst: number
  members: TeamMember[]
}

interface Game {
  id: string
  date: string
  homeTeam: {
    id: string
    name: string
    logo: string | null
  }
  awayTeam: {
    id: string
    name: string
    logo: string | null
  }
  homeScore: number
  awayScore: number
  status: string
}

export default function TeamDetailsPage() {
  const params = useParams()
  const teamId = params.id as string

  const [team, setTeam] = useState<Team | null>(null)
  const [games, setGames] = useState<Game[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const loadTeamData = async () => {
      setIsLoading(true)
      try {
        // Fetch team details
        const teamResponse = await fetchTeamDetails(teamId)
        if (teamResponse.data) {
          setTeam(teamResponse.data)
        }

        // Fetch team games
        const gamesResponse = await fetchGames(teamId)
        if (gamesResponse.data) {
          setGames(gamesResponse.data)
        }
      } catch (error) {
        console.error("Error loading team data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    if (teamId) {
      loadTeamData()
    }
  }, [teamId])

  if (isLoading) {
    return (
      <div className="container py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-muted rounded w-1/3 mb-6"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="h-64 bg-muted rounded"></div>
            <div className="h-64 bg-muted rounded"></div>
          </div>
          <div className="h-8 bg-muted rounded w-1/4 mb-4"></div>
          <div className="h-64 bg-muted rounded"></div>
        </div>
      </div>
    )
  }

  if (!team) {
    return (
      <div className="container py-8">
        <div className="text-center py-12">
          <Users className="h-12 w-12 mx-auto text-muted-foreground" />
          <p className="mt-4 text-muted-foreground">Team not found.</p>
        </div>
      </div>
    )
  }

  // Sort roster by position (C, LW, RW, LD, RD, G)
  const sortedRoster = [...team.members].sort((a, b) => {
    const positionOrder = { C: 1, LW: 2, RW: 3, LD: 4, RD: 5, G: 6 }
    const posA = a.user.playerStats?.position || "Z"
    const posB = b.user.playerStats?.position || "Z"
    return (
      (positionOrder[posA as keyof typeof positionOrder] || 99) -
      (positionOrder[posB as keyof typeof positionOrder] || 99)
    )
  })

  // Format date for schedule
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
    })
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">{team.name}</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Team Information</CardTitle>
            <CardDescription>
              {team.conference} Conference • {team.division} Division
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            {team.logo ? (
              <Image src={team.logo || "/placeholder.svg"} alt={team.name} width={150} height={150} className="mb-4" />
            ) : (
              <div className="w-32 h-32 bg-muted rounded-full flex items-center justify-center mb-4">
                <Users className="h-16 w-16 text-muted-foreground" />
              </div>
            )}
            <div className="text-center mt-4">
              <p className="text-lg font-bold">
                {team.wins}-{team.losses}-{team.otl}
              </p>
              <p className="text-xl font-bold">{team.points} PTS</p>
              <p className="text-sm text-muted-foreground mt-2">
                GF: {team.goalsFor} | GA: {team.goalsAgainst} | DIFF: {team.goalsFor - team.goalsAgainst}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Team Management</CardTitle>
            <CardDescription>Owners, General Managers, and Coaches</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {team.members
                .filter((member) => ["OWNER", "GM", "COACH"].includes(member.role))
                .map((member) => (
                  <div key={member.id} className="flex items-center gap-4 p-2 border-b last:border-0">
                    {member.user.image ? (
                      <Image
                        src={member.user.image || "/placeholder.svg"}
                        alt={member.user.name || "User"}
                        width={40}
                        height={40}
                        className="rounded-full"
                      />
                    ) : (
                      <div className="w-10 h-10 bg-muted rounded-full flex items-center justify-center">
                        <Users className="h-5 w-5 text-muted-foreground" />
                      </div>
                    )}
                    <div>
                      <p className="font-medium">{member.user.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {member.role === "OWNER" ? "Owner" : member.role === "GM" ? "General Manager" : "Coach"}
                      </p>
                    </div>
                  </div>
                ))}

              {team.members.filter((member) => ["OWNER", "GM", "COACH"].includes(member.role)).length === 0 && (
                <div className="text-center py-4">
                  <p className="text-muted-foreground">No management staff assigned yet.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="roster" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="roster">
            <Users className="mr-2 h-4 w-4" /> Team Roster
          </TabsTrigger>
          <TabsTrigger value="schedule">
            <Calendar className="mr-2 h-4 w-4" /> Schedule
          </TabsTrigger>
          <TabsTrigger value="stats">
            <BarChart3 className="mr-2 h-4 w-4" /> Team Stats
          </TabsTrigger>
        </TabsList>

        <TabsContent value="roster">
          <Card>
            <CardHeader>
              <CardTitle>Team Roster</CardTitle>
              <CardDescription>Players currently on the {team.name}</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Player</TableHead>
                    <TableHead>Position</TableHead>
                    <TableHead>GP</TableHead>
                    <TableHead>G</TableHead>
                    <TableHead>A</TableHead>
                    <TableHead>PTS</TableHead>
                    <TableHead>+/-</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sortedRoster
                    .filter((member) => member.role === "PLAYER")
                    .map((member) => (
                      <TableRow key={member.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            {member.user.image ? (
                              <Image
                                src={member.user.image || "/placeholder.svg"}
                                alt={member.user.name || "User"}
                                width={24}
                                height={24}
                                className="rounded-full"
                              />
                            ) : (
                              <div className="w-6 h-6 bg-muted rounded-full"></div>
                            )}
                            {member.user.name}
                          </div>
                        </TableCell>
                        <TableCell>{member.user.playerStats?.position || "N/A"}</TableCell>
                        <TableCell>{member.user.playerStats?.gamesPlayed || 0}</TableCell>
                        <TableCell>{member.user.playerStats?.goals || 0}</TableCell>
                        <TableCell>{member.user.playerStats?.assists || 0}</TableCell>
                        <TableCell>{member.user.playerStats?.points || 0}</TableCell>
                        <TableCell>
                          {member.user.playerStats?.plusMinus !== undefined
                            ? member.user.playerStats.plusMinus > 0
                              ? `+${member.user.playerStats.plusMinus}`
                              : member.user.playerStats.plusMinus
                            : 0}
                        </TableCell>
                      </TableRow>
                    ))}

                  {sortedRoster.filter((member) => member.role === "PLAYER").length === 0 && (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center py-4">
                        <p className="text-muted-foreground">No players on the roster yet.</p>
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schedule">
          <Card>
            <CardHeader>
              <CardTitle>Team Schedule</CardTitle>
              <CardDescription>Upcoming and past games for the {team.name}</CardDescription>
            </CardHeader>
            <CardContent>
              {games.length > 0 ? (
                <div className="space-y-4">
                  {games.map((game) => (
                    <div key={game.id} className="flex items-center justify-between p-3 border rounded-md">
                      <div className="flex items-center gap-2">
                        <div className="text-sm font-medium">{formatDate(game.date)}</div>
                      </div>

                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2">
                          {game.awayTeam.logo ? (
                            <Image
                              src={game.awayTeam.logo || "/placeholder.svg"}
                              alt={game.awayTeam.name}
                              width={24}
                              height={24}
                            />
                          ) : (
                            <div className="w-6 h-6 bg-muted rounded-full"></div>
                          )}
                          <span className="font-medium">{game.awayTeam.name}</span>
                        </div>

                        {game.status === "FINAL" ? (
                          <div className="text-center min-w-[60px]">
                            <span className="font-bold">
                              {game.awayScore} - {game.homeScore}
                            </span>
                          </div>
                        ) : (
                          <div className="text-center min-w-[60px]">
                            <span className="text-xs text-muted-foreground">@</span>
                          </div>
                        )}

                        <div className="flex items-center gap-2">
                          {game.homeTeam.logo ? (
                            <Image
                              src={game.homeTeam.logo || "/placeholder.svg"}
                              alt={game.homeTeam.name}
                              width={24}
                              height={24}
                            />
                          ) : (
                            <div className="w-6 h-6 bg-muted rounded-full"></div>
                          )}
                          <span className="font-medium">{game.homeTeam.name}</span>
                        </div>
                      </div>

                      <div>
                        <span
                          className={`text-xs px-2 py-1 rounded-full ${
                            game.status === "FINAL"
                              ? "bg-muted"
                              : game.status === "LIVE"
                                ? "bg-green-100 text-green-800"
                                : "bg-blue-100 text-blue-800"
                          }`}
                        >
                          {game.status === "FINAL" ? "Final" : game.status === "LIVE" ? "Live" : "Scheduled"}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Calendar className="h-12 w-12 mx-auto text-muted-foreground" />
                  <p className="mt-4 text-muted-foreground">No games scheduled yet.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="stats">
          <Card>
            <CardHeader>
              <CardTitle>Team Statistics</CardTitle>
              <CardDescription>Detailed stats for the {team.name}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Team Overview</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Games Played</span>
                      <span className="font-medium">{team.wins + team.losses + team.otl}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Record</span>
                      <span className="font-medium">
                        {team.wins}-{team.losses}-{team.otl}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Points</span>
                      <span className="font-medium">{team.points}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Win Percentage</span>
                      <span className="font-medium">
                        {team.wins + team.losses + team.otl > 0
                          ? ((team.wins / (team.wins + team.losses + team.otl)) * 100).toFixed(1) + "%"
                          : "0.0%"}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Goals For</span>
                      <span className="font-medium">{team.goalsFor}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Goals Against</span>
                      <span className="font-medium">{team.goalsAgainst}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Goal Differential</span>
                      <span className="font-medium">
                        {team.goalsFor - team.goalsAgainst > 0
                          ? `+${team.goalsFor - team.goalsAgainst}`
                          : team.goalsFor - team.goalsAgainst}
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">Team Leaders</h3>
                  <div className="space-y-4">
                    {/* Points Leader */}
                    <div className="p-3 border rounded-md">
                      <p className="text-sm text-muted-foreground">Points Leader</p>
                      {team.members.filter((m) => m.role === "PLAYER" && m.user.playerStats).length > 0 ? (
                        (() => {
                          const pointsLeader = [...team.members]
                            .filter((m) => m.role === "PLAYER" && m.user.playerStats)
                            .sort((a, b) => (b.user.playerStats?.points || 0) - (a.user.playerStats?.points || 0))[0]

                          return (
                            <div className="flex items-center gap-2 mt-1">
                              {pointsLeader.user.image ? (
                                <Image
                                  src={pointsLeader.user.image || "/placeholder.svg"}
                                  alt={pointsLeader.user.name || "User"}
                                  width={24}
                                  height={24}
                                  className="rounded-full"
                                />
                              ) : (
                                <div className="w-6 h-6 bg-muted rounded-full"></div>
                              )}
                              <span className="font-medium">{pointsLeader.user.name}</span>
                              <span className="ml-auto font-bold">
                                {pointsLeader.user.playerStats?.points || 0} PTS
                              </span>
                            </div>
                          )
                        })()
                      ) : (
                        <p className="text-sm mt-1">No data available</p>
                      )}
                    </div>

                    {/* Goals Leader */}
                    <div className="p-3 border rounded-md">
                      <p className="text-sm text-muted-foreground">Goals Leader</p>
                      {team.members.filter((m) => m.role === "PLAYER" && m.user.playerStats).length > 0 ? (
                        (() => {
                          const goalsLeader = [...team.members]
                            .filter((m) => m.role === "PLAYER" && m.user.playerStats)
                            .sort((a, b) => (b.user.playerStats?.goals || 0) - (a.user.playerStats?.goals || 0))[0]

                          return (
                            <div className="flex items-center gap-2 mt-1">
                              {goalsLeader.user.image ? (
                                <Image
                                  src={goalsLeader.user.image || "/placeholder.svg"}
                                  alt={goalsLeader.user.name || "User"}
                                  width={24}
                                  height={24}
                                  className="rounded-full"
                                />
                              ) : (
                                <div className="w-6 h-6 bg-muted rounded-full"></div>
                              )}
                              <span className="font-medium">{goalsLeader.user.name}</span>
                              <span className="ml-auto font-bold">{goalsLeader.user.playerStats?.goals || 0} G</span>
                            </div>
                          )
                        })()
                      ) : (
                        <p className="text-sm mt-1">No data available</p>
                      )}
                    </div>

                    {/* Assists Leader */}
                    <div className="p-3 border rounded-md">
                      <p className="text-sm text-muted-foreground">Assists Leader</p>
                      {team.members.filter((m) => m.role === "PLAYER" && m.user.playerStats).length > 0 ? (
                        (() => {
                          const assistsLeader = [...team.members]
                            .filter((m) => m.role === "PLAYER" && m.user.playerStats)
                            .sort((a, b) => (b.user.playerStats?.assists || 0) - (a.user.playerStats?.assists || 0))[0]

                          return (
                            <div className="flex items-center gap-2 mt-1">
                              {assistsLeader.user.image ? (
                                <Image
                                  src={assistsLeader.user.image || "/placeholder.svg"}
                                  alt={assistsLeader.user.name || "User"}
                                  width={24}
                                  height={24}
                                  className="rounded-full"
                                />
                              ) : (
                                <div className="w-6 h-6 bg-muted rounded-full"></div>
                              )}
                              <span className="font-medium">{assistsLeader.user.name}</span>
                              <span className="ml-auto font-bold">
                                {assistsLeader.user.playerStats?.assists || 0} A
                              </span>
                            </div>
                          )
                        })()
                      ) : (
                        <p className="text-sm mt-1">No data available</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
