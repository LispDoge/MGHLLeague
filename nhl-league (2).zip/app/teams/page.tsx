"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Search, Users } from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { fetchTeams } from "@/lib/api-utils"

interface Team {
  id: string
  name: string
  abbreviation: string
  logo: string | null
  conference: string
  division: string
  wins: number
  losses: number
  otl: number
  points: number
}

export default function TeamsPage() {
  const [teams, setTeams] = useState<Team[]>([])
  const [filteredTeams, setFilteredTeams] = useState<Team[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("all")

  useEffect(() => {
    const loadTeams = async () => {
      setIsLoading(true)
      try {
        const response = await fetchTeams()
        if (response.data) {
          setTeams(response.data)
          setFilteredTeams(response.data)
        }
      } catch (error) {
        console.error("Error loading teams:", error)
      } finally {
        setIsLoading(false)
      }
    }

    loadTeams()
  }, [])

  useEffect(() => {
    // Filter teams based on search query and active tab
    let filtered = teams

    // Filter by conference/division
    if (activeTab === "eastern") {
      filtered = filtered.filter((team) => team.conference === "EASTERN")
    } else if (activeTab === "western") {
      filtered = filtered.filter((team) => team.conference === "WESTERN")
    } else if (activeTab === "atlantic") {
      filtered = filtered.filter((team) => team.division === "ATLANTIC")
    } else if (activeTab === "metropolitan") {
      filtered = filtered.filter((team) => team.division === "METROPOLITAN")
    } else if (activeTab === "central") {
      filtered = filtered.filter((team) => team.division === "CENTRAL")
    } else if (activeTab === "pacific") {
      filtered = filtered.filter((team) => team.division === "PACIFIC")
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (team) => team.name.toLowerCase().includes(query) || team.abbreviation.toLowerCase().includes(query),
      )
    }

    setFilteredTeams(filtered)
  }, [teams, searchQuery, activeTab])

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value)
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">NHL 25 League Teams</h1>

      <div className="flex items-center space-x-2 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search teams..."
            className="pl-8"
            value={searchQuery}
            onChange={handleSearch}
          />
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Teams</TabsTrigger>
          <TabsTrigger value="eastern">Eastern Conference</TabsTrigger>
          <TabsTrigger value="western">Western Conference</TabsTrigger>
          <TabsTrigger value="atlantic">Atlantic</TabsTrigger>
          <TabsTrigger value="metropolitan">Metropolitan</TabsTrigger>
          <TabsTrigger value="central">Central</TabsTrigger>
          <TabsTrigger value="pacific">Pacific</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {isLoading ? (
              Array(8)
                .fill(0)
                .map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <CardHeader className="pb-2">
                      <div className="h-6 bg-muted rounded w-3/4"></div>
                      <div className="h-4 bg-muted rounded w-1/2 mt-2"></div>
                    </CardHeader>
                    <CardContent className="flex justify-center py-6">
                      <div className="h-24 w-24 bg-muted rounded-full"></div>
                    </CardContent>
                  </Card>
                ))
            ) : filteredTeams.length > 0 ? (
              filteredTeams.map((team) => (
                <Link href={`/teams/${team.id}`} key={team.id}>
                  <Card className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-2">
                      <CardTitle>{team.name}</CardTitle>
                      <CardDescription>
                        {team.conference} Conference • {team.division} Division
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="flex flex-col items-center justify-center py-4">
                      {team.logo ? (
                        <Image
                          src={team.logo || "/placeholder.svg"}
                          alt={team.name}
                          width={80}
                          height={80}
                          className="mb-2"
                        />
                      ) : (
                        <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mb-2">
                          <Users className="h-10 w-10 text-muted-foreground" />
                        </div>
                      )}
                      <div className="text-sm text-center mt-2">
                        <p className="font-medium">
                          {team.wins}-{team.losses}-{team.otl}
                        </p>
                        <p className="text-muted-foreground">{team.points} PTS</p>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <Users className="h-12 w-12 mx-auto text-muted-foreground" />
                <p className="mt-4 text-muted-foreground">No teams found matching your search criteria.</p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Other tab contents will show the same content, filtered by the useEffect */}
        <TabsContent value="eastern" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {/* Same content as "all" tab, filtered by the useEffect */}
            {filteredTeams.map((team) => (
              <Link href={`/teams/${team.id}`} key={team.id}>
                <Card className="hover:shadow-md transition-shadow">
                  <CardHeader className="pb-2">
                    <CardTitle>{team.name}</CardTitle>
                    <CardDescription>
                      {team.conference} Conference • {team.division} Division
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="flex flex-col items-center justify-center py-4">
                    {team.logo ? (
                      <Image
                        src={team.logo || "/placeholder.svg"}
                        alt={team.name}
                        width={80}
                        height={80}
                        className="mb-2"
                      />
                    ) : (
                      <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center mb-2">
                        <Users className="h-10 w-10 text-muted-foreground" />
                      </div>
                    )}
                    <div className="text-sm text-center mt-2">
                      <p className="font-medium">
                        {team.wins}-{team.losses}-{team.otl}
                      </p>
                      <p className="text-muted-foreground">{team.points} PTS</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </TabsContent>

        {/* Repeat the same pattern for other tabs */}
        <TabsContent value="western" className="mt-0">
          {/* Same structure as above */}
        </TabsContent>
        <TabsContent value="atlantic" className="mt-0">
          {/* Same structure as above */}
        </TabsContent>
        <TabsContent value="metropolitan" className="mt-0">
          {/* Same structure as above */}
        </TabsContent>
        <TabsContent value="central" className="mt-0">
          {/* Same structure as above */}
        </TabsContent>
        <TabsContent value="pacific" className="mt-0">
          {/* Same structure as above */}
        </TabsContent>
      </Tabs>
    </div>
  )
}
