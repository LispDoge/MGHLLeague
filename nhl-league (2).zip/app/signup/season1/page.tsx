"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Trophy, AlertCircle, Loader2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { signIn, useSession } from "next-auth/react"
import Image from "next/image"

export default function Season1SignUp() {
  const { data: session, status } = useSession()
  const [primaryPosition, setPrimaryPosition] = useState("")
  const [secondaryPosition, setSecondaryPosition] = useState("")
  const [gamerTag, setGamerTag] = useState("")
  const [console, setConsole] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState(false)

  const handleDiscordConnect = () => {
    signIn("discord", { callbackUrl: window.location.href })
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError("")

    // Validate form
    if (!primaryPosition || !secondaryPosition || !gamerTag || !console) {
      setError("Please fill out all fields")
      setIsSubmitting(false)
      return
    }

    // Validate Discord connection
    if (status !== "authenticated") {
      setError("You must connect your Discord account to sign up")
      setIsSubmitting(false)
      return
    }

    try {
      // Submit the form data to the API
      const response = await fetch("/api/signup/season1", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          primaryPosition,
          secondaryPosition,
          gamerTag,
          console,
          discordId: session?.user?.discordId,
          userId: session?.user?.id,
        }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.message || "Failed to submit registration")
      }

      setSuccess(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to submit. Please try again.")
    } finally {
      setIsSubmitting(false)
    }
  }

  if (success) {
    return (
      <div className="container max-w-md py-12">
        <Card>
          <CardHeader>
            <CardTitle className="text-center">Registration Successful!</CardTitle>
            <CardDescription className="text-center">Your Season 1 registration has been submitted</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center space-y-4 pt-6">
            <Trophy className="h-16 w-16 text-green-500" />
            <p className="text-center">
              Thank you for signing up for Season 1 of the NHL 25 League. Please check your Discord for further
              instructions.
            </p>
          </CardContent>
          <CardFooter className="flex justify-center">
            <Button asChild>
              <a href="/">Return to Home</a>
            </Button>
          </CardFooter>
        </Card>
      </div>
    )
  }

  return (
    <div className="container max-w-md py-12">
      <Card>
        <CardHeader>
          <CardTitle>Season 1 Sign Up</CardTitle>
          <CardDescription>Register for Season 1 of the NHL 25 League</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="discord">Discord Connection</Label>
              {status === "loading" ? (
                <Button variant="outline" className="w-full" disabled>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Loading...
                </Button>
              ) : status === "authenticated" ? (
                <div className="flex items-center p-2 border rounded-md">
                  {session.user.image && (
                    <Image
                      src={session.user.image || "/placeholder.svg"}
                      alt={session.user.name || "User"}
                      width={32}
                      height={32}
                      className="rounded-full mr-2"
                    />
                  )}
                  <div className="flex-1">
                    <p className="text-sm font-medium">{session.user.name}</p>
                    <p className="text-xs text-muted-foreground">Connected via Discord</p>
                  </div>
                  <Button variant="ghost" size="sm" type="button" className="ml-auto">
                    Change
                  </Button>
                </div>
              ) : (
                <>
                  <Button variant="outline" className="w-full" type="button" onClick={handleDiscordConnect}>
                    Connect Discord Account
                  </Button>
                  <p className="text-xs text-muted-foreground">You must connect your Discord account to sign up</p>
                </>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="primaryPosition">Primary Position</Label>
              <Select value={primaryPosition} onValueChange={setPrimaryPosition}>
                <SelectTrigger>
                  <SelectValue placeholder="Select position" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="C">Center (C)</SelectItem>
                  <SelectItem value="LW">Left Wing (LW)</SelectItem>
                  <SelectItem value="RW">Right Wing (RW)</SelectItem>
                  <SelectItem value="LD">Left Defense (LD)</SelectItem>
                  <SelectItem value="RD">Right Defense (RD)</SelectItem>
                  <SelectItem value="G">Goalie (G)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="secondaryPosition">Secondary Position</Label>
              <Select value={secondaryPosition} onValueChange={setSecondaryPosition}>
                <SelectTrigger>
                  <SelectValue placeholder="Select position" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="C">Center (C)</SelectItem>
                  <SelectItem value="LW">Left Wing (LW)</SelectItem>
                  <SelectItem value="RW">Right Wing (RW)</SelectItem>
                  <SelectItem value="LD">Left Defense (LD)</SelectItem>
                  <SelectItem value="RD">Right Defense (RD)</SelectItem>
                  <SelectItem value="G">Goalie (G)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="gamerTag">Xbox/PSN Gamer Tag</Label>
              <Input
                id="gamerTag"
                value={gamerTag}
                onChange={(e) => setGamerTag(e.target.value)}
                placeholder="Enter your gamer tag"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="console">Console</Label>
              <Select value={console} onValueChange={setConsole}>
                <SelectTrigger>
                  <SelectValue placeholder="Select console" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Xbox">Xbox</SelectItem>
                  <SelectItem value="PSN">PlayStation (PSN)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button type="submit" className="w-full" disabled={isSubmitting || status !== "authenticated"}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Submitting...
                </>
              ) : (
                "Submit Registration"
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
