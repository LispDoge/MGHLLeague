"use client"

import { useState, useEffect } from "react"
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Loader2 } from "lucide-react"

interface Team {
  id: string
  name: string
  wins: number
  losses: number
  otl: number
  points: number
  goalsFor: number
  goalsAgainst: number
  conference: string
  division: string
}

export default function StandingsPage() {
  const [teams, setTeams] = useState<Team[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("overall")

  useEffect(() => {
    const fetchStandings = async () => {
      setIsLoading(true)
      try {
        const response = await fetch("/api/teams")
        const data = await response.json()
        if (data.data) {
          setTeams(data.data)
        }
      } catch (error) {
        console.error("Error fetching standings:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchStandings()
  }, [])

  // Filter and sort teams based on active tab
  const getFilteredTeams = () => {
    let filtered = [...teams]

    // Filter by conference/division
    if (activeTab === "eastern") {
      filtered = filtered.filter((team) => team.conference === "EASTERN")
    } else if (activeTab === "western") {
      filtered = filtered.filter((team) => team.conference === "WESTERN")
    } else if (activeTab === "atlantic") {
      filtered = filtered.filter((team) => team.division === "ATLANTIC")
    } else if (activeTab === "metropolitan") {
      filtered = filtered.filter((team) => team.division === "METROPOLITAN")
    } else if (activeTab === "central") {
      filtered = filtered.filter((team) => team.division === "CENTRAL")
    } else if (activeTab === "pacific") {
      filtered = filtered.filter((team) => team.division === "PACIFIC")
    }

    // Sort by points, then wins
    return filtered.sort((a, b) => {
      if (a.points !== b.points) {
        return b.points - a.points
      }
      return b.wins - a.wins
    })
  }

  const filteredTeams = getFilteredTeams()

  if (isLoading) {
    return (
      <div className="container py-8 flex justify-center items-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">League Standings</h1>

      <Tabs defaultValue="overall" className="w-full" onValueChange={setActiveTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="overall">Overall</TabsTrigger>
          <TabsTrigger value="eastern">Eastern Conference</TabsTrigger>
          <TabsTrigger value="western">Western Conference</TabsTrigger>
          <TabsTrigger value="atlantic">Atlantic</TabsTrigger>
          <TabsTrigger value="metropolitan">Metropolitan</TabsTrigger>
          <TabsTrigger value="central">Central</TabsTrigger>
          <TabsTrigger value="pacific">Pacific</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab}>
          <Table>
            <TableCaption>Current NHL 25 League Standings</TableCaption>
            <TableHeader>
              <TableRow>
                <TableHead>Rank</TableHead>
                <TableHead>Team</TableHead>
                <TableHead>GP</TableHead>
                <TableHead>W</TableHead>
                <TableHead>L</TableHead>
                <TableHead>OTL</TableHead>
                <TableHead>PTS</TableHead>
                <TableHead>GF</TableHead>
                <TableHead>GA</TableHead>
                <TableHead>DIFF</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTeams.map((team, index) => (
                <TableRow key={team.id}>
                  <TableCell>{index + 1}</TableCell>
                  <TableCell className="font-medium">{team.name}</TableCell>
                  <TableCell>{team.wins + team.losses + team.otl}</TableCell>
                  <TableCell>{team.wins}</TableCell>
                  <TableCell>{team.losses}</TableCell>
                  <TableCell>{team.otl}</TableCell>
                  <TableCell className="font-bold">{team.points}</TableCell>
                  <TableCell>{team.goalsFor}</TableCell>
                  <TableCell>{team.goalsAgainst}</TableCell>
                  <TableCell>{team.goalsFor - team.goalsAgainst}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>
      </Tabs>
    </div>
  )
}
