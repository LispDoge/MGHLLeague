"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, DollarSign, ArrowLeftRight, UserPlus } from "lucide-react"
import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Mock data for team roster
const players = [
  { id: 1, name: "John Smith", position: "C", salary: 8500000, contract: "2 years" },
  { id: 2, name: "Mike Johnson", position: "LW", salary: 7250000, contract: "3 years" },
  { id: 3, name: "David Williams", position: "RW", salary: 6750000, contract: "1 year" },
  { id: 4, name: "Robert Brown", position: "LD", salary: 5500000, contract: "4 years" },
  { id: 5, name: "James Davis", position: "RD", salary: 4750000, contract: "2 years" },
  { id: 6, name: "Thomas Wilson", position: "G", salary: 6250000, contract: "3 years" },
]

// Mock data for free agents
const freeAgents = [
  { id: 101, name: "Alex Thompson", position: "C", asking: 5750000 },
  { id: 102, name: "Ryan Mitchell", position: "LW", asking: 4500000 },
  { id: 103, name: "Chris Anderson", position: "RD", asking: 3750000 },
  { id: 104, name: "Kevin Martin", position: "G", asking: 5250000 },
]

export default function TeamManagementPage() {
  const [searchRoster, setSearchRoster] = useState("")
  const [searchFreeAgents, setSearchFreeAgents] = useState("")

  // Format salary as currency
  const formatSalary = (salary: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 0,
    }).format(salary)
  }

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Team Management</h1>

      <Tabs defaultValue="roster" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="roster">Team Roster</TabsTrigger>
          <TabsTrigger value="free-agents">Free Agents</TabsTrigger>
          <TabsTrigger value="trades">Trade Center</TabsTrigger>
          <TabsTrigger value="salary">Salary Cap</TabsTrigger>
        </TabsList>

        <TabsContent value="roster">
          <Card>
            <CardHeader>
              <CardTitle>Toronto Maple Leafs Roster</CardTitle>
              <CardDescription>Manage your team's roster and player contracts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div className="relative max-w-sm">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                  <Input
                    type="search"
                    placeholder="Search roster..."
                    className="pl-8"
                    value={searchRoster}
                    onChange={(e) => setSearchRoster(e.target.value)}
                  />
                </div>
                <Button>
                  <UserPlus className="mr-2 h-4 w-4" /> Add Player
                </Button>
              </div>

              <Table>
                <TableCaption>Current team roster and contracts</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Player</TableHead>
                    <TableHead>Position</TableHead>
                    <TableHead>Salary</TableHead>
                    <TableHead>Contract</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {players.map((player) => (
                    <TableRow key={player.id}>
                      <TableCell className="font-medium">{player.name}</TableCell>
                      <TableCell>{player.position}</TableCell>
                      <TableCell>{formatSalary(player.salary)}</TableCell>
                      <TableCell>{player.contract}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="outline" size="sm">
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="free-agents">
          <Card>
            <CardHeader>
              <CardTitle>Free Agent Market</CardTitle>
              <CardDescription>Bid on available free agents to improve your team</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative max-w-sm mb-4">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  type="search"
                  placeholder="Search free agents..."
                  className="pl-8"
                  value={searchFreeAgents}
                  onChange={(e) => setSearchFreeAgents(e.target.value)}
                />
              </div>

              <Table>
                <TableCaption>Available free agents</TableCaption>
                <TableHeader>
                  <TableRow>
                    <TableHead>Player</TableHead>
                    <TableHead>Position</TableHead>
                    <TableHead>Asking Price</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {freeAgents.map((agent) => (
                    <TableRow key={agent.id}>
                      <TableCell className="font-medium">{agent.name}</TableCell>
                      <TableCell>{agent.position}</TableCell>
                      <TableCell>{formatSalary(agent.asking)}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="default" size="sm">
                          <DollarSign className="mr-2 h-4 w-4" /> Place Bid
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trades">
          <Card>
            <CardHeader>
              <CardTitle>Trade Center</CardTitle>
              <CardDescription>Propose and manage trades with other teams</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col space-y-4">
                <Button className="w-fit">
                  <ArrowLeftRight className="mr-2 h-4 w-4" /> Propose New Trade
                </Button>

                <div className="rounded-md border p-4 bg-muted/50">
                  <h3 className="font-medium mb-2">No Active Trade Proposals</h3>
                  <p className="text-sm text-muted-foreground">
                    You currently have no active trade proposals. Use the button above to propose a new trade.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="salary">
          <Card>
            <CardHeader>
              <CardTitle>Salary Cap Management</CardTitle>
              <CardDescription>Track your team's salary cap situation</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="flex flex-col space-y-2">
                  <div className="flex justify-between">
                    <span>Salary Cap</span>
                    <span className="font-bold">{formatSalary(82500000)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Current Payroll</span>
                    <span className="font-bold">{formatSalary(79000000)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cap Space</span>
                    <span className="font-bold text-green-600">{formatSalary(3500000)}</span>
                  </div>
                </div>

                <div className="w-full bg-muted rounded-full h-4">
                  <div className="bg-primary h-4 rounded-full" style={{ width: "95.8%" }}></div>
                </div>

                <div className="rounded-md border p-4">
                  <h3 className="font-medium mb-2">Salary Breakdown by Position</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Forwards</span>
                      <span>{formatSalary(45500000)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Defense</span>
                      <span>{formatSalary(27250000)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Goaltending</span>
                      <span>{formatSalary(6250000)}</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
