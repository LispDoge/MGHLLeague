import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getServerSession } from "next-auth/next"

const prisma = new PrismaClient()

export async function GET(request: Request) {
  try {
    // Parse query parameters
    const { searchParams } = new URL(request.url)
    const conference = searchParams.get("conference")
    const division = searchParams.get("division")

    // Build the query
    const where = {}
    if (conference) {
      where.conference = conference.toUpperCase()
    }
    if (division) {
      where.division = division.toUpperCase()
    }

    // Fetch teams with their stats
    const teams = await prisma.team.findMany({
      where,
      orderBy: [{ points: "desc" }, { wins: "desc" }],
    })

    return NextResponse.json({ data: teams })
  } catch (error) {
    console.error("Error fetching standings:", error)
    return NextResponse.json({ error: "Failed to fetch standings" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    // Check authentication and authorization
    const session = await getServerSession()

    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only admins can update standings
    if (session.user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const body = await request.json()
    const { teamId, stats } = body

    // Update team stats
    const updatedTeam = await prisma.team.update({
      where: {
        id: teamId,
      },
      data: {
        wins: stats.wins,
        losses: stats.losses,
        otl: stats.otl,
        points: stats.points,
        goalsFor: stats.goalsFor,
        goalsAgainst: stats.goalsAgainst,
      },
    })

    return NextResponse.json({
      success: true,
      message: "Standings updated successfully",
      data: updatedTeam,
    })
  } catch (error) {
    console.error("Error updating standings:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to update standings",
      },
      { status: 500 },
    )
  }
}
