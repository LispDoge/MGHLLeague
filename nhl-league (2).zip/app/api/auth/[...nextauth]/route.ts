import NextAuth from "next-auth"
import DiscordProvider from "next-auth/providers/discord"
import { PrismaAdapter } from "@auth/prisma-adapter"
import prisma from "@/lib/prisma"

// Configure scopes for Discord - we need these to access user information
const scopes = ["identify", "email", "guilds"].join(" ")

const handler = NextAuth({
  adapter: PrismaAdapter(prisma),
  providers: [
    DiscordProvider({
      clientId: process.env.DISCORD_CLIENT_ID || "",
      clientSecret: process.env.DISCORD_CLIENT_SECRET || "",
      authorization: { params: { scope: scopes } },
      profile(profile) {
        if (profile.avatar === null) {
          const defaultAvatarNumber = Number.parseInt(profile.discriminator) % 5
          profile.image_url = `https://cdn.discordapp.com/embed/avatars/${defaultAvatarNumber}.png`
        } else {
          const format = profile.avatar.startsWith("a_") ? "gif" : "png"
          profile.image_url = `https://cdn.discordapp.com/avatars/${profile.id}/${profile.avatar}.${format}`
        }

        return {
          id: profile.id,
          name: profile.username,
          email: profile.email,
          image: profile.image_url,
          discordId: profile.id,
          discriminator: profile.discriminator,
        }
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user, account }) {
      // Add role and Discord info to JWT token if it exists on the user
      if (user) {
        token.role = user.role || "PLAYER" // Default role is player
        token.userId = user.id

        // If this is a Discord login, store the Discord ID
        if (account?.provider === "discord") {
          token.discordId = user.discordId
        }
      }
      return token
    },
    async session({ session, token }) {
      // Add role and user ID to session
      if (token?.role) {
        session.user.role = token.role
      }
      if (token?.userId) {
        session.user.id = token.userId
      }
      if (token?.discordId) {
        session.user.discordId = token.discordId
      }
      return session
    },
  },
  pages: {
    signIn: "/login",
    error: "/auth/error",
  },
  session: {
    strategy: "jwt",
  },
})

export { handler as GET, handler as POST }
