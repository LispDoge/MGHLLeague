import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getServerSession } from "next-auth/next"

const prisma = new PrismaClient()

export async function GET(request: Request) {
  try {
    // Parse query parameters
    const { searchParams } = new URL(request.url)
    const teamId = searchParams.get("teamId")
    const season = searchParams.get("season") ? Number.parseInt(searchParams.get("season")) : undefined
    const status = searchParams.get("status")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const skip = (page - 1) * limit

    // Build the query
    const where = {}
    if (teamId) {
      where.OR = [{ homeTeamId: teamId }, { awayTeamId: teamId }]
    }
    if (season) {
      where.season = season
    }
    if (status) {
      where.status = status.toUpperCase()
    }

    // Fetch games
    const games = await prisma.game.findMany({
      where,
      include: {
        homeTeam: true,
        awayTeam: true,
      },
      orderBy: { date: "asc" },
      take: limit,
      skip,
    })

    // Get total count for pagination
    const total = await prisma.game.count({ where })

    return NextResponse.json({
      data: games,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Error fetching games:", error)
    return NextResponse.json({ error: "Failed to fetch games" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    // Check authentication and authorization
    const session = await getServerSession()

    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only admins can create games
    if (session.user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const body = await request.json()
    const { homeTeamId, awayTeamId, date, season } = body

    // Create new game
    const game = await prisma.game.create({
      data: {
        homeTeamId,
        awayTeamId,
        date: new Date(date),
        season,
        status: "SCHEDULED",
      },
      include: {
        homeTeam: true,
        awayTeam: true,
      },
    })

    return NextResponse.json({
      success: true,
      message: "Game created successfully",
      data: game,
    })
  } catch (error) {
    console.error("Error creating game:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to create game",
      },
      { status: 500 },
    )
  }
}
