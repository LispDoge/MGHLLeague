import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getServerSession } from "next-auth/next"

const prisma = new PrismaClient()

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const teamId = params.id

    // Fetch team with roster
    const team = await prisma.team.findUnique({
      where: { id: teamId },
      include: {
        members: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                image: true,
                playerStats: true,
              },
            },
          },
        },
      },
    })

    if (!team) {
      return NextResponse.json({ error: "Team not found" }, { status: 404 })
    }

    return NextResponse.json({ data: team })
  } catch (error) {
    console.error("Error fetching team:", error)
    return NextResponse.json({ error: "Failed to fetch team" }, { status: 500 })
  }
}

export async function PUT(request: Request, { params }: { params: { id: string } }) {
  try {
    // Check authentication and authorization
    const session = await getServerSession()

    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const teamId = params.id
    const body = await request.json()

    // Check if user is admin or team owner/GM
    const isAdmin = session.user.role === "admin"
    const isTeamManager = await prisma.teamMember.findFirst({
      where: {
        teamId,
        userId: session.user.id,
        role: { in: ["OWNER", "GM"] },
      },
    })

    if (!isAdmin && !isTeamManager) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Update team
    const updatedTeam = await prisma.team.update({
      where: { id: teamId },
      data: body,
    })

    return NextResponse.json({
      success: true,
      message: "Team updated successfully",
      data: updatedTeam,
    })
  } catch (error) {
    console.error("Error updating team:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to update team",
      },
      { status: 500 },
    )
  }
}

export async function DELETE(request: Request, { params }: { params: { id: string } }) {
  try {
    // Check authentication and authorization
    const session = await getServerSession()

    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only admins can delete teams
    if (session.user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const teamId = params.id

    // Delete team
    await prisma.team.delete({
      where: { id: teamId },
    })

    return NextResponse.json({
      success: true,
      message: "Team deleted successfully",
    })
  } catch (error) {
    console.error("Error deleting team:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to delete team",
      },
      { status: 500 },
    )
  }
}
