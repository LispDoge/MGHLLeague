import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getServerSession } from "next-auth/next"

const prisma = new PrismaClient()

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const teamId = params.id

    // Fetch team roster
    const roster = await prisma.teamMember.findMany({
      where: { teamId },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            image: true,
            playerStats: true,
          },
        },
      },
    })

    return NextResponse.json({ data: roster })
  } catch (error) {
    console.error("Error fetching roster:", error)
    return NextResponse.json({ error: "Failed to fetch roster" }, { status: 500 })
  }
}

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    // Check authentication and authorization
    const session = await getServerSession()

    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const teamId = params.id
    const body = await request.json()
    const { userId, role } = body

    // Check if user is admin or team owner/GM
    const isAdmin = session.user.role === "admin"
    const isTeamManager = await prisma.teamMember.findFirst({
      where: {
        teamId,
        userId: session.user.id,
        role: { in: ["OWNER", "GM"] },
      },
    })

    if (!isAdmin && !isTeamManager) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    // Add player to team
    const teamMember = await prisma.teamMember.create({
      data: {
        teamId,
        userId,
        role,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            image: true,
            playerStats: true,
          },
        },
      },
    })

    return NextResponse.json({
      success: true,
      message: "Player added to team successfully",
      data: teamMember,
    })
  } catch (error) {
    console.error("Error adding player to team:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to add player to team",
      },
      { status: 500 },
    )
  }
}
