import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"

export async function GET(request: Request) {
  try {
    // Parse query parameters
    const { searchParams } = new URL(request.url)
    const conference = searchParams.get("conference")
    const division = searchParams.get("division")
    const includeRoster = searchParams.get("includeRoster") === "true"

    // Build the query
    const where: any = {}
    if (conference) {
      where.conference = conference.toUpperCase()
    }
    if (division) {
      where.division = division.toUpperCase()
    }

    // Include options
    const include: any = {}
    if (includeRoster) {
      include.members = {
        include: {
          user: {
            select: {
              id: true,
              name: true,
              image: true,
              playerStats: true,
            },
          },
        },
      }
    }

    // Fetch teams
    const teams = await prisma.team.findMany({
      where,
      include: includeRoster ? include : undefined,
      orderBy: { name: "asc" },
    })

    return NextResponse.json({ data: teams })
  } catch (error) {
    console.error("Error fetching teams:", error)
    return NextResponse.json({ error: "Failed to fetch teams" }, { status: 500 })
  }
}
