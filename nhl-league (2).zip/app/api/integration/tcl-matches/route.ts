import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import prisma from "@/lib/prisma"

// This route integrates with the tcl-matches GitHub repo
// It will handle the API calls to update stats and standings

export async function POST(request: Request) {
  try {
    // Check authentication and authorization
    const session = await getServerSession()

    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only admins can update stats via this endpoint
    if (session.user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const body = await request.json()
    const { gameId, homeScore, awayScore, playerStats } = body

    // Start a transaction to update everything at once
    await prisma.$transaction(async (tx) => {
      // 1. Update the game with scores
      const game = await tx.game.update({
        where: { id: gameId },
        data: {
          homeScore,
          awayScore,
          status: "FINAL",
        },
        include: {
          homeTeam: true,
          awayTeam: true,
        },
      })

      // 2. Update team records and standings
      const homeTeamWin = homeScore > awayScore
      const overtime = body.overtime || false

      // Update home team
      await tx.team.update({
        where: { id: game.homeTeamId },
        data: {
          wins: homeTeamWin ? { increment: 1 } : undefined,
          losses: homeTeamWin ? undefined : overtime ? undefined : { increment: 1 },
          otl: homeTeamWin ? undefined : overtime ? { increment: 1 } : undefined,
          points: homeTeamWin ? { increment: 2 } : overtime ? { increment: 1 } : undefined,
          goalsFor: { increment: homeScore },
          goalsAgainst: { increment: awayScore },
        },
      })

      // Update away team
      await tx.team.update({
        where: { id: game.awayTeamId },
        data: {
          wins: homeTeamWin ? undefined : { increment: 1 },
          losses: homeTeamWin ? (overtime ? undefined : { increment: 1 }) : undefined,
          otl: homeTeamWin ? (overtime ? { increment: 1 } : undefined) : undefined,
          points: homeTeamWin ? (overtime ? { increment: 1 } : undefined) : { increment: 2 },
          goalsFor: { increment: awayScore },
          goalsAgainst: { increment: homeScore },
        },
      })

      // 3. Update player stats
      if (playerStats && Array.isArray(playerStats)) {
        // Create game stats entries
        await Promise.all(
          playerStats.map(async (stat) => {
            // Create game stat record
            await tx.gameStat.create({
              data: {
                gameId,
                playerId: stat.playerId,
                goals: stat.goals || 0,
                assists: stat.assists || 0,
                plusMinus: stat.plusMinus || 0,
                pim: stat.pim || 0,
                shots: stat.shots || 0,
                hits: stat.hits || 0,
                blocks: stat.blocks || 0,
              },
            })

            // Update player's overall stats
            await tx.playerStats.update({
              where: { userId: stat.playerId },
              data: {
                gamesPlayed: { increment: 1 },
                goals: { increment: stat.goals || 0 },
                assists: { increment: stat.assists || 0 },
                points: { increment: (stat.goals || 0) + (stat.assists || 0) },
                plusMinus: { increment: stat.plusMinus || 0 },
                pim: { increment: stat.pim || 0 },
                hits: { increment: stat.hits || 0 },
                blocks: { increment: stat.blocks || 0 },
              },
            })
          }),
        )
      }
    })

    return NextResponse.json({
      success: true,
      message: "Game results and stats updated successfully",
    })
  } catch (error) {
    console.error("Error updating game results:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to update game results",
      },
      { status: 500 },
    )
  }
}
