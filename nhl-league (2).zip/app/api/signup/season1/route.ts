import { NextResponse } from "next/server"
import { getServerSession } from "next-auth/next"
import { PrismaClient } from "@prisma/client"

const prisma = new PrismaClient()

export async function POST(request: Request) {
  try {
    // Get the session to verify the user is authenticated
    const session = await getServerSession()

    if (!session || !session.user) {
      return NextResponse.json({ success: false, message: "You must be logged in to register" }, { status: 401 })
    }

    // Parse the request body
    const body = await request.json()
    const { primaryPosition, secondaryPosition, gamerTag, console, userId } = body

    // Validate required fields
    if (!primaryPosition || !secondaryPosition || !gamerTag || !console) {
      return NextResponse.json({ success: false, message: "All fields are required" }, { status: 400 })
    }

    // Check if the user has already registered for Season 1
    const existingRegistration = await prisma.seasonRegistration.findFirst({
      where: {
        userId: userId,
        season: 1,
      },
    })

    if (existingRegistration) {
      return NextResponse.json({ success: false, message: "You have already registered for Season 1" }, { status: 400 })
    }

    // Create the season registration
    const registration = await prisma.seasonRegistration.create({
      data: {
        season: 1,
        primaryPosition,
        secondaryPosition,
        gamerTag,
        console,
        user: {
          connect: {
            id: userId,
          },
        },
        status: "PENDING", // Default status is pending until approved
      },
    })

    return NextResponse.json({
      success: true,
      message: "Registration submitted successfully",
      data: registration,
    })
  } catch (error) {
    console.error("Error in Season 1 registration:", error)
    return NextResponse.json({ success: false, message: "Failed to submit registration" }, { status: 500 })
  }
}
