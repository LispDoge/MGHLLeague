import { NextResponse } from "next/server"
import { PrismaClient } from "@prisma/client"
import { getServerSession } from "next-auth/next"

const prisma = new PrismaClient()

export async function GET(request: Request) {
  try {
    // Parse query parameters
    const { searchParams } = new URL(request.url)
    const type = searchParams.get("type") || "offense"
    const teamId = searchParams.get("teamId")
    const limit = Number.parseInt(searchParams.get("limit") || "100")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const skip = (page - 1) * limit

    let data = []

    // Return different data based on the type
    if (type === "offense") {
      // Get offensive players (forwards)
      const players = await prisma.playerStats.findMany({
        where: {
          position: {
            in: ["C", "LW", "RW"],
          },
          ...(teamId
            ? {
                user: {
                  teamMemberships: {
                    some: {
                      teamId,
                    },
                  },
                },
              }
            : {}),
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              teamMemberships: {
                include: {
                  team: {
                    select: {
                      id: true,
                      name: true,
                      abbreviation: true,
                    },
                  },
                },
              },
            },
          },
        },
        orderBy: {
          points: "desc",
        },
        take: limit,
        skip,
      })

      // Format the data for the response
      data = players.map((player) => ({
        id: player.id,
        name: player.user.name,
        team: player.user.teamMemberships[0]?.team.name || "Free Agent",
        position: player.position,
        gp: player.gamesPlayed,
        g: player.goals,
        a: player.assists,
        pts: player.points,
        plusMinus: player.plusMinus,
        pim: player.pim,
        ppg: player.ppg,
        shg: player.shg,
      }))
    } else if (type === "defense") {
      // Get defensive players
      const players = await prisma.playerStats.findMany({
        where: {
          position: {
            in: ["LD", "RD"],
          },
          ...(teamId
            ? {
                user: {
                  teamMemberships: {
                    some: {
                      teamId,
                    },
                  },
                },
              }
            : {}),
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              teamMemberships: {
                include: {
                  team: {
                    select: {
                      id: true,
                      name: true,
                      abbreviation: true,
                    },
                  },
                },
              },
            },
          },
        },
        orderBy: {
          points: "desc",
        },
        take: limit,
        skip,
      })

      // Format the data for the response
      data = players.map((player) => ({
        id: player.id,
        name: player.user.name,
        team: player.user.teamMemberships[0]?.team.name || "Free Agent",
        position: player.position,
        gp: player.gamesPlayed,
        g: player.goals,
        a: player.assists,
        pts: player.points,
        plusMinus: player.plusMinus,
        pim: player.pim,
        hits: player.hits,
        blocks: player.blocks,
      }))
    } else if (type === "goalie") {
      // Get goalies
      const players = await prisma.playerStats.findMany({
        where: {
          position: "G",
          ...(teamId
            ? {
                user: {
                  teamMemberships: {
                    some: {
                      teamId,
                    },
                  },
                },
              }
            : {}),
        },
        include: {
          user: {
            select: {
              id: true,
              name: true,
              teamMemberships: {
                include: {
                  team: {
                    select: {
                      id: true,
                      name: true,
                      abbreviation: true,
                    },
                  },
                },
              },
            },
          },
        },
        orderBy: {
          gamesPlayed: "desc",
        },
        take: limit,
        skip,
      })

      // For goalies, we would need additional stats like GAA, SV%, etc.
      // This is a simplified version
      data = players.map((player) => ({
        id: player.id,
        name: player.user.name,
        team: player.user.teamMemberships[0]?.team.name || "Free Agent",
        gp: player.gamesPlayed,
        w: 0, // These would come from game results
        l: 0,
        otl: 0,
        gaa: 0,
        sv: 0,
        so: 0,
      }))
    }

    return NextResponse.json({ data, page, limit, total: data.length })
  } catch (error) {
    console.error("Error fetching stats:", error)
    return NextResponse.json({ error: "Failed to fetch stats" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    // Check authentication and authorization
    const session = await getServerSession()

    if (!session || !session.user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Only admins can update stats
    if (session.user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 })
    }

    const body = await request.json()
    const { playerId, stats } = body

    // Update player stats
    const updatedStats = await prisma.playerStats.update({
      where: {
        id: playerId,
      },
      data: stats,
    })

    return NextResponse.json({
      success: true,
      message: "Stats updated successfully",
      data: updatedStats,
    })
  } catch (error) {
    console.error("Error updating stats:", error)
    return NextResponse.json(
      {
        success: false,
        message: "Failed to update stats",
      },
      { status: 500 },
    )
  }
}
