"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Trophy, BarChart3, User, Calendar, Award } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import Image from "next/image"

// Mock data for player stats
const playerStats = {
  name: "John Smith",
  position: "Center",
  team: "Toronto Maple Leafs",
  gamesPlayed: 18,
  goals: 12,
  assists: 15,
  points: 27,
  plusMinus: 8,
  pim: 10,
}

// Mock data for upcoming games
const upcomingGames = [
  { id: 1, date: "2023-11-15", time: "7:00 PM", opponent: "Montreal Canadiens", location: "Home" },
  { id: 2, date: "2023-11-18", time: "8:00 PM", opponent: "Boston Bruins", location: "Away" },
  { id: 3, date: "2023-11-21", time: "7:30 PM", opponent: "New York Rangers", location: "Home" },
]

// Mock data for awards
const awards = [
  { id: 1, name: "Player of the Week", date: "October 24, 2023" },
  { id: 2, name: "3 Stars of the Game", date: "November 5, 2023" },
]

export default function DashboardPage() {
  return (
    <div className="container py-8">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-6">
        <div className="flex items-center gap-4">
          <div className="rounded-full bg-muted p-2">
            <User className="h-8 w-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold">Welcome, John Smith</h1>
            <p className="text-muted-foreground">Center | Toronto Maple Leafs</p>
          </div>
        </div>
        <div className="mt-4 md:mt-0">
          <Button>Edit Profile</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Games Played</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{playerStats.gamesPlayed}</div>
            <p className="text-xs text-muted-foreground">Season 1</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Points</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{playerStats.points}</div>
            <p className="text-xs text-muted-foreground">
              {playerStats.goals} G, {playerStats.assists} A
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Plus/Minus</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {playerStats.plusMinus > 0 ? `+${playerStats.plusMinus}` : playerStats.plusMinus}
            </div>
            <p className="text-xs text-muted-foreground">Team Rank: 3rd</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="stats" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="stats">
            <BarChart3 className="mr-2 h-4 w-4" /> My Stats
          </TabsTrigger>
          <TabsTrigger value="schedule">
            <Calendar className="mr-2 h-4 w-4" /> Schedule
          </TabsTrigger>
          <TabsTrigger value="awards">
            <Award className="mr-2 h-4 w-4" /> Awards
          </TabsTrigger>
          <TabsTrigger value="team">
            <Trophy className="mr-2 h-4 w-4" /> My Team
          </TabsTrigger>
        </TabsList>

        <TabsContent value="stats">
          <Card>
            <CardHeader>
              <CardTitle>Player Statistics</CardTitle>
              <CardDescription>Your performance in Season 1</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Offensive Stats</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Games Played</span>
                      <span className="font-medium">{playerStats.gamesPlayed}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Goals</span>
                      <span className="font-medium">{playerStats.goals}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Assists</span>
                      <span className="font-medium">{playerStats.assists}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Points</span>
                      <span className="font-medium">{playerStats.points}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Points Per Game</span>
                      <span className="font-medium">{(playerStats.points / playerStats.gamesPlayed).toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-semibold mb-4">Defensive Stats</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Plus/Minus</span>
                      <span className="font-medium">
                        {playerStats.plusMinus > 0 ? `+${playerStats.plusMinus}` : playerStats.plusMinus}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>PIM</span>
                      <span className="font-medium">{playerStats.pim}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Hits</span>
                      <span className="font-medium">24</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Blocks</span>
                      <span className="font-medium">8</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Takeaways</span>
                      <span className="font-medium">15</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schedule">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Games</CardTitle>
              <CardDescription>Your team's schedule for the next few games</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Time</TableHead>
                    <TableHead>Opponent</TableHead>
                    <TableHead>Location</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {upcomingGames.map((game) => (
                    <TableRow key={game.id}>
                      <TableCell>{game.date}</TableCell>
                      <TableCell>{game.time}</TableCell>
                      <TableCell>{game.opponent}</TableCell>
                      <TableCell>{game.location}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="awards">
          <Card>
            <CardHeader>
              <CardTitle>Player Awards</CardTitle>
              <CardDescription>Achievements and recognition</CardDescription>
            </CardHeader>
            <CardContent>
              {awards.length > 0 ? (
                <div className="space-y-4">
                  {awards.map((award) => (
                    <div key={award.id} className="flex items-center gap-4 p-4 border rounded-lg">
                      <Award className="h-8 w-8 text-yellow-500" />
                      <div>
                        <h3 className="font-medium">{award.name}</h3>
                        <p className="text-sm text-muted-foreground">{award.date}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Award className="h-12 w-12 mx-auto text-muted-foreground" />
                  <p className="mt-4 text-muted-foreground">No awards yet. Keep playing to earn recognition!</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="team">
          <Card>
            <CardHeader>
              <CardTitle>Toronto Maple Leafs</CardTitle>
              <CardDescription>Your team information and roster</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Team Stats</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Record</span>
                      <span className="font-medium">15-5-2</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Points</span>
                      <span className="font-medium">32</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Standing</span>
                      <span className="font-medium">1st in Division</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Goals For</span>
                      <span className="font-medium">78</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Goals Against</span>
                      <span className="font-medium">54</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col items-center justify-center">
                  <Image
                    src="/placeholder.svg?height=150&width=150"
                    alt="Toronto Maple Leafs"
                    width={150}
                    height={150}
                    className="mb-4"
                  />
                  <Button>View Full Roster</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
