import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Trophy, Users, BarChart3, Award, UserPlus, LogIn } from "lucide-react"
import Image from "next/image"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32 bg-[#041E42] text-white">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-[1fr_400px] lg:gap-12">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">NHL 25 League</h1>
                  <p className="max-w-[600px] text-gray-300 md:text-xl">
                    Join our competitive NHL 25 gaming league. Track your stats, climb the standings, and compete for
                    trophies.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/signup/season1">
                    <Button size="lg" className="bg-[#A4A9AD] text-[#041E42] hover:bg-[#C4CCD4]">
                      <UserPlus className="mr-2 h-4 w-4" /> Season 1 Sign Up
                    </Button>
                  </Link>
                  <Link href="/login">
                    <Button size="lg" variant="outline" className="border-[#A4A9AD] text-[#A4A9AD] hover:bg-[#0A2D57]">
                      <LogIn className="mr-2 h-4 w-4" /> Login
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <Image
                  src="/placeholder.svg?height=300&width=400"
                  alt="NHL 25 League"
                  width={400}
                  height={300}
                  className="rounded-lg object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">League Features</h2>
                <p className="max-w-[900px] text-muted-foreground md:text-xl">
                  Everything you need to enjoy competitive NHL 25 gaming
                </p>
              </div>
            </div>
            <div className="mx-auto grid max-w-5xl items-center gap-6 py-12 lg:grid-cols-3">
              <div className="flex flex-col items-center space-y-4 rounded-lg border p-6">
                <Trophy className="h-12 w-12 text-[#041E42]" />
                <h3 className="text-xl font-bold">Standings & Records</h3>
                <p className="text-center text-muted-foreground">
                  Track your team's performance with detailed standings and records
                </p>
              </div>
              <div className="flex flex-col items-center space-y-4 rounded-lg border p-6">
                <BarChart3 className="h-12 w-12 text-[#041E42]" />
                <h3 className="text-xl font-bold">Comprehensive Stats</h3>
                <p className="text-center text-muted-foreground">
                  Detailed statistics for offense, defense, and goalie performance
                </p>
              </div>
              <div className="flex flex-col items-center space-y-4 rounded-lg border p-6">
                <Award className="h-12 w-12 text-[#041E42]" />
                <h3 className="text-xl font-bold">Awards & Trophies</h3>
                <p className="text-center text-muted-foreground">
                  Earn recognition for your achievements throughout the season
                </p>
              </div>
            </div>
          </div>
        </section>

        <section className="w-full py-12 md:py-24 lg:py-32 bg-muted">
          <div className="container px-4 md:px-6">
            <div className="grid gap-10 lg:grid-cols-2">
              <div className="flex flex-col justify-center space-y-4">
                <div className="space-y-2">
                  <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">Join Our Community</h2>
                  <p className="max-w-[600px] text-muted-foreground md:text-xl">
                    Connect with other NHL 25 players, participate in league events, and compete for glory.
                  </p>
                </div>
                <div className="flex flex-col gap-2 min-[400px]:flex-row">
                  <Link href="/signup/season1">
                    <Button size="lg">
                      <Users className="mr-2 h-4 w-4" /> Sign Up Now
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="flex items-center justify-center">
                <Image
                  src="/placeholder.svg?height=300&width=500"
                  alt="NHL Community"
                  width={500}
                  height={300}
                  className="rounded-lg object-cover"
                />
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}
