"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Plus, Users, Trophy, BarChart3, UserCog, FileText } from "lucide-react"

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState("dashboard")

  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input type="search" placeholder="Search..." className="pl-8 w-[200px] md:w-[300px]" />
          </div>
          <Button>
            <Plus className="mr-2 h-4 w-4" /> New
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="md:col-span-1">
          <Card>
            <CardContent className="p-4">
              <nav className="flex flex-col space-y-1">
                <Button
                  variant={activeTab === "dashboard" ? "default" : "ghost"}
                  className="justify-start"
                  onClick={() => setActiveTab("dashboard")}
                >
                  <BarChart3 className="mr-2 h-4 w-4" />
                  Dashboard
                </Button>
                <Button
                  variant={activeTab === "players" ? "default" : "ghost"}
                  className="justify-start"
                  onClick={() => setActiveTab("players")}
                >
                  <Users className="mr-2 h-4 w-4" />
                  Players
                </Button>
                <Button
                  variant={activeTab === "teams" ? "default" : "ghost"}
                  className="justify-start"
                  onClick={() => setActiveTab("teams")}
                >
                  <Trophy className="mr-2 h-4 w-4" />
                  Teams
                </Button>
                <Button
                  variant={activeTab === "stats" ? "default" : "ghost"}
                  className="justify-start"
                  onClick={() => setActiveTab("stats")}
                >
                  <BarChart3 className="mr-2 h-4 w-4" />
                  Stats
                </Button>
                <Button
                  variant={activeTab === "standings" ? "default" : "ghost"}
                  className="justify-start"
                  onClick={() => setActiveTab("standings")}
                >
                  <Trophy className="mr-2 h-4 w-4" />
                  Standings
                </Button>
                <Button
                  variant={activeTab === "users" ? "default" : "ghost"}
                  className="justify-start"
                  onClick={() => setActiveTab("users")}
                >
                  <UserCog className="mr-2 h-4 w-4" />
                  Users
                </Button>
                <Button
                  variant={activeTab === "reports" ? "default" : "ghost"}
                  className="justify-start"
                  onClick={() => setActiveTab("reports")}
                >
                  <FileText className="mr-2 h-4 w-4" />
                  Reports
                </Button>
              </nav>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle>
                {activeTab === "dashboard" && "Admin Dashboard"}
                {activeTab === "players" && "Manage Players"}
                {activeTab === "teams" && "Manage Teams"}
                {activeTab === "stats" && "Edit Statistics"}
                {activeTab === "standings" && "Edit Standings"}
                {activeTab === "users" && "User Management"}
                {activeTab === "reports" && "Reports"}
              </CardTitle>
              <CardDescription>
                {activeTab === "dashboard" && "Overview of your NHL 25 League"}
                {activeTab === "players" && "Add, edit, or remove players"}
                {activeTab === "teams" && "Manage team rosters and information"}
                {activeTab === "stats" && "Edit player and team statistics"}
                {activeTab === "standings" && "Update league standings"}
                {activeTab === "users" && "Manage user accounts and permissions"}
                {activeTab === "reports" && "Generate and view reports"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {activeTab === "dashboard" && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Total Players</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">128</div>
                      <p className="text-xs text-muted-foreground">+12 from last season</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Total Teams</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">32</div>
                      <p className="text-xs text-muted-foreground">All teams filled</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Games Played</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">86</div>
                      <p className="text-xs text-muted-foreground">Season 1 in progress</p>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-medium">Active Users</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">245</div>
                      <p className="text-xs text-muted-foreground">+32 this week</p>
                    </CardContent>
                  </Card>
                </div>
              )}

              {activeTab === "players" && (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">Player management interface will be displayed here.</p>
                  <p className="text-muted-foreground">Add, edit, or remove players from the league.</p>
                </div>
              )}

              {activeTab === "teams" && (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">Team management interface will be displayed here.</p>
                  <p className="text-muted-foreground">Manage team rosters, trades, and information.</p>
                </div>
              )}

              {activeTab === "stats" && (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">Statistics editing interface will be displayed here.</p>
                  <p className="text-muted-foreground">Edit player and team statistics manually.</p>
                </div>
              )}

              {activeTab === "standings" && (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">Standings editing interface will be displayed here.</p>
                  <p className="text-muted-foreground">Update league standings and team records.</p>
                </div>
              )}

              {activeTab === "users" && (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">User management interface will be displayed here.</p>
                  <p className="text-muted-foreground">Manage user accounts, roles, and permissions.</p>
                </div>
              )}

              {activeTab === "reports" && (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">Reports interface will be displayed here.</p>
                  <p className="text-muted-foreground">Generate and view various league reports.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
