"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Search, Plus, Calendar, Loader2 } from "lucide-react"
import { fetchTeams, fetchGames } from "@/lib/api-utils"
import { scheduleGame, submitGameResults } from "@/lib/tcl-matches-integration"
import { useSession } from "next-auth/react"
import { useRouter } from "next/navigation"

interface Team {
  id: string
  name: string
}

interface Game {
  id: string
  date: string
  homeTeam: {
    id: string
    name: string
  }
  awayTeam: {
    id: string
    name: string
  }
  homeScore: number
  awayScore: number
  status: string
}

export default function AdminGamesPage() {
  const { data: session, status } = useSession()
  const router = useRouter()

  const [teams, setTeams] = useState<Team[]>([])
  const [games, setGames] = useState<Game[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")

  // New game form state
  const [homeTeamId, setHomeTeamId] = useState("")
  const [awayTeamId, setAwayTeamId] = useState("")
  const [gameDate, setGameDate] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Game result form state
  const [selectedGame, setSelectedGame] = useState<Game | null>(null)
  const [homeScore, setHomeScore] = useState(0)
  const [awayScore, setAwayScore] = useState(0)
  const [isOvertime, setIsOvertime] = useState(false)
  const [isSubmittingResult, setIsSubmittingResult] = useState(false)

  useEffect(() => {
    // Redirect if not admin
    if (status === "authenticated" && session.user.role !== "admin") {
      router.push("/dashboard")
    }

    const loadData = async () => {
      setIsLoading(true)
      try {
        // Fetch teams
        const teamsResponse = await fetchTeams()
        if (teamsResponse.data) {
          setTeams(teamsResponse.data)
        }

        // Fetch games
        const gamesResponse = await fetchGames()
        if (gamesResponse.data) {
          setGames(gamesResponse.data)
        }
      } catch (error) {
        console.error("Error loading data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    if (status === "authenticated") {
      loadData()
    }
  }, [status, session, router])

  const handleCreateGame = async () => {
    if (!homeTeamId || !awayTeamId || !gameDate) {
      alert("Please fill out all fields")
      return
    }

    if (homeTeamId === awayTeamId) {
      alert("Home team and away team cannot be the same")
      return
    }

    setIsSubmitting(true)
    try {
      const result = await scheduleGame(
        homeTeamId,
        awayTeamId,
        new Date(gameDate),
        1, // Season 1
      )

      if (result.success) {
        // Refresh games list
        const gamesResponse = await fetchGames()
        if (gamesResponse.data) {
          setGames(gamesResponse.data)
        }

        // Reset form
        setHomeTeamId("")
        setAwayTeamId("")
        setGameDate("")
      } else {
        alert(result.message || "Failed to create game")
      }
    } catch (error) {
      console.error("Error creating game:", error)
      alert("An error occurred while creating the game")
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleSubmitResult = async () => {
    if (!selectedGame) return

    setIsSubmittingResult(true)
    try {
      // In a real implementation, you would collect player stats here
      // This is a simplified version
      const result = await submitGameResults({
        gameId: selectedGame.id,
        homeScore,
        awayScore,
        overtime: isOvertime,
        playerStats: [], // In a real implementation, you would collect player stats
      })

      if (result.success) {
        // Refresh games list
        const gamesResponse = await fetchGames()
        if (gamesResponse.data) {
          setGames(gamesResponse.data)
        }

        // Reset form
        setSelectedGame(null)
        setHomeScore(0)
        setAwayScore(0)
        setIsOvertime(false)
      } else {
        alert(result.message || "Failed to submit game result")
      }
    } catch (error) {
      console.error("Error submitting game result:", error)
      alert("An error occurred while submitting the game result")
    } finally {
      setIsSubmittingResult(false)
    }
  }

  // Filter games based on search query
  const filteredGames = games.filter((game) => {
    if (!searchQuery) return true

    const query = searchQuery.toLowerCase()
    return game.homeTeam.name.toLowerCase().includes(query) || game.awayTeam.name.toLowerCase().includes(query)
  })

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  if (status === "loading" || (status === "authenticated" && isLoading)) {
    return (
      <div className="container py-8">
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        </div>
      </div>
    )
  }

  if (status === "authenticated" && session.user.role !== "admin") {
    return null // Will redirect in useEffect
  }

  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Game Management</h1>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search games..."
              className="pl-8 w-[200px] md:w-[300px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Schedule Game
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Schedule New Game</DialogTitle>
                <DialogDescription>Create a new game in the NHL 25 League schedule.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="homeTeam">Home Team</Label>
                  <Select value={homeTeamId} onValueChange={setHomeTeamId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select home team" />
                    </SelectTrigger>
                    <SelectContent>
                      {teams.map((team) => (
                        <SelectItem key={team.id} value={team.id}>
                          {team.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="awayTeam">Away Team</Label>
                  <Select value={awayTeamId} onValueChange={setAwayTeamId}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select away team" />
                    </SelectTrigger>
                    <SelectContent>
                      {teams.map((team) => (
                        <SelectItem key={team.id} value={team.id}>
                          {team.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="gameDate">Game Date</Label>
                  <Input
                    id="gameDate"
                    type="datetime-local"
                    value={gameDate}
                    onChange={(e) => setGameDate(e.target.value)}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleCreateGame} disabled={isSubmitting}>
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Scheduling...
                    </>
                  ) : (
                    "Schedule Game"
                  )}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Game Schedule</CardTitle>
          <CardDescription>Manage and update games in the NHL 25 League</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Home Team</TableHead>
                <TableHead>Away Team</TableHead>
                <TableHead>Score</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredGames.length > 0 ? (
                filteredGames.map((game) => (
                  <TableRow key={game.id}>
                    <TableCell>{formatDate(game.date)}</TableCell>
                    <TableCell className="font-medium">{game.homeTeam.name}</TableCell>
                    <TableCell>{game.awayTeam.name}</TableCell>
                    <TableCell>{game.status === "FINAL" ? `${game.homeScore} - ${game.awayScore}` : "-"}</TableCell>
                    <TableCell>
                      <span
                        className={`text-xs px-2 py-1 rounded-full ${
                          game.status === "FINAL"
                            ? "bg-muted"
                            : game.status === "LIVE"
                              ? "bg-green-100 text-green-800"
                              : "bg-blue-100 text-blue-800"
                        }`}
                      >
                        {game.status === "FINAL" ? "Final" : game.status === "LIVE" ? "Live" : "Scheduled"}
                      </span>
                    </TableCell>
                    <TableCell className="text-right">
                      {game.status !== "FINAL" && (
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" onClick={() => setSelectedGame(game)}>
                              Enter Result
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Enter Game Result</DialogTitle>
                              <DialogDescription>
                                {selectedGame && (
                                  <>
                                    {selectedGame.homeTeam.name} vs {selectedGame.awayTeam.name} on{" "}
                                    {formatDate(selectedGame.date)}
                                  </>
                                )}
                              </DialogDescription>
                            </DialogHeader>
                            <div className="grid gap-4 py-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div className="grid gap-2">
                                  <Label htmlFor="homeScore">{selectedGame?.homeTeam.name} Score</Label>
                                  <Input
                                    id="homeScore"
                                    type="number"
                                    min="0"
                                    value={homeScore}
                                    onChange={(e) => setHomeScore(Number.parseInt(e.target.value) || 0)}
                                  />
                                </div>
                                <div className="grid gap-2">
                                  <Label htmlFor="awayScore">{selectedGame?.awayTeam.name} Score</Label>
                                  <Input
                                    id="awayScore"
                                    type="number"
                                    min="0"
                                    value={awayScore}
                                    onChange={(e) => setAwayScore(Number.parseInt(e.target.value) || 0)}
                                  />
                                </div>
                              </div>
                              <div className="flex items-center space-x-2">
                                <input
                                  type="checkbox"
                                  id="overtime"
                                  checked={isOvertime}
                                  onChange={(e) => setIsOvertime(e.target.checked)}
                                  className="h-4 w-4 rounded border-gray-300"
                                />
                                <Label htmlFor="overtime">Game went to overtime/shootout</Label>
                              </div>
                            </div>
                            <DialogFooter>
                              <Button onClick={handleSubmitResult} disabled={isSubmittingResult}>
                                {isSubmittingResult ? (
                                  <>
                                    <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Submitting...
                                  </>
                                ) : (
                                  "Submit Result"
                                )}
                              </Button>
                            </DialogFooter>
                          </DialogContent>
                        </Dialog>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-4">
                    <Calendar className="h-12 w-12 mx-auto text-muted-foreground" />
                    <p className="mt-2 text-muted-foreground">
                      {searchQuery ? "No games found matching your search." : "No games scheduled yet."}
                    </p>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
