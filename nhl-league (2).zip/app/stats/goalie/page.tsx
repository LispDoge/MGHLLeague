import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

// This would be fetched from the API in a real implementation
const goalies = [
  {
    id: 1,
    name: "Andrei Vasilevskiy",
    team: "Tampa Bay Lightning",
    gp: 18,
    w: 12,
    l: 4,
    otl: 2,
    gaa: 2.15,
    sv: 0.925,
    so: 3,
  },
  { id: 2, name: "Igor Shesterkin", team: "New York Rangers", gp: 17, w: 11, l: 5, otl: 1, gaa: 2.2, sv: 0.923, so: 2 },
  { id: 3, name: "Ilya Sorokin", team: "New York Islanders", gp: 16, w: 10, l: 5, otl: 1, gaa: 2.25, sv: 0.92, so: 2 },
  { id: 4, name: "Connor Hellebuyck", team: "Winnipeg Jets", gp: 18, w: 11, l: 6, otl: 1, gaa: 2.3, sv: 0.918, so: 1 },
  { id: 5, name: "Juuse Saros", team: "Nashville Predators", gp: 17, w: 9, l: 6, otl: 2, gaa: 2.35, sv: 0.917, so: 1 },
  { id: 6, name: "Jacob Markstrom", team: "Calgary Flames", gp: 16, w: 8, l: 7, otl: 1, gaa: 2.4, sv: 0.915, so: 1 },
  { id: 7, name: "Thatcher Demko", team: "Vancouver Canucks", gp: 15, w: 8, l: 6, otl: 1, gaa: 2.45, sv: 0.914, so: 0 },
  {
    id: 8,
    name: "Frederik Andersen",
    team: "Carolina Hurricanes",
    gp: 14,
    w: 7,
    l: 5,
    otl: 2,
    gaa: 2.5,
    sv: 0.912,
    so: 0,
  },
]

// Sort goalies by wins
const sortedGoalies = [...goalies].sort((a, b) => b.w - a.w)

export default function GoalieStatsPage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Goalie Statistics</h1>

      <div className="flex items-center space-x-2 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input type="search" placeholder="Search goalies..." className="pl-8" />
        </div>
        <Button variant="outline">Filter</Button>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableCaption>NHL 25 League Goalie Statistics</TableCaption>
          <TableHeader>
            <TableRow>
              <TableHead>Rank</TableHead>
              <TableHead>Goalie</TableHead>
              <TableHead>Team</TableHead>
              <TableHead>GP</TableHead>
              <TableHead>W</TableHead>
              <TableHead>L</TableHead>
              <TableHead>OTL</TableHead>
              <TableHead>GAA</TableHead>
              <TableHead>SV%</TableHead>
              <TableHead>SO</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedGoalies.map((goalie, index) => (
              <TableRow key={goalie.id}>
                <TableCell>{index + 1}</TableCell>
                <TableCell className="font-medium">{goalie.name}</TableCell>
                <TableCell>{goalie.team}</TableCell>
                <TableCell>{goalie.gp}</TableCell>
                <TableCell className="font-bold">{goalie.w}</TableCell>
                <TableCell>{goalie.l}</TableCell>
                <TableCell>{goalie.otl}</TableCell>
                <TableCell>{goalie.gaa.toFixed(2)}</TableCell>
                <TableCell>{goalie.sv.toFixed(3)}</TableCell>
                <TableCell>{goalie.so}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
