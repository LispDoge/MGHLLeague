import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

// This would be fetched from the API in a real implementation
const players = [
  {
    id: 1,
    name: "Connor McDavid",
    team: "Edmonton Oilers",
    position: "C",
    gp: 20,
    g: 15,
    a: 25,
    pts: 40,
    plusMinus: 12,
    pim: 8,
    ppg: 5,
    shg: 1,
  },
  {
    id: 2,
    name: "Leon Draisaitl",
    team: "Edmonton Oilers",
    position: "C",
    gp: 20,
    g: 12,
    a: 18,
    pts: 30,
    plusMinus: 8,
    pim: 12,
    ppg: 4,
    shg: 0,
  },
  {
    id: 3,
    name: "Auston Matthews",
    team: "Toronto Maple Leafs",
    position: "C",
    gp: 19,
    g: 18,
    a: 10,
    pts: 28,
    plusMinus: 6,
    pim: 4,
    ppg: 7,
    shg: 0,
  },
  {
    id: 4,
    name: "Nathan MacKinnon",
    team: "Colorado Avalanche",
    position: "C",
    gp: 20,
    g: 10,
    a: 17,
    pts: 27,
    plusMinus: 10,
    pim: 6,
    ppg: 3,
    shg: 1,
  },
  {
    id: 5,
    name: "Mitch Marner",
    team: "Toronto Maple Leafs",
    position: "RW",
    gp: 19,
    g: 8,
    a: 18,
    pts: 26,
    plusMinus: 5,
    pim: 2,
    ppg: 2,
    shg: 2,
  },
  {
    id: 6,
    name: "David Pastrnak",
    team: "Boston Bruins",
    position: "RW",
    gp: 18,
    g: 14,
    a: 11,
    pts: 25,
    plusMinus: 7,
    pim: 10,
    ppg: 6,
    shg: 0,
  },
  {
    id: 7,
    name: "Nikita Kucherov",
    team: "Tampa Bay Lightning",
    position: "RW",
    gp: 17,
    g: 11,
    a: 13,
    pts: 24,
    plusMinus: 4,
    pim: 8,
    ppg: 5,
    shg: 0,
  },
  {
    id: 8,
    name: "Artemi Panarin",
    team: "New York Rangers",
    position: "LW",
    gp: 20,
    g: 9,
    a: 15,
    pts: 24,
    plusMinus: 6,
    pim: 4,
    ppg: 3,
    shg: 0,
  },
]

// Sort players by points
const sortedPlayers = [...players].sort((a, b) => b.pts - a.pts)

export default function OffenseStatsPage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Offensive Statistics</h1>

      <div className="flex items-center space-x-2 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input type="search" placeholder="Search players..." className="pl-8" />
        </div>
        <Button variant="outline">Filter</Button>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableCaption>NHL 25 League Offensive Statistics</TableCaption>
          <TableHeader>
            <TableRow>
              <TableHead>Rank</TableHead>
              <TableHead>Player</TableHead>
              <TableHead>Team</TableHead>
              <TableHead>Pos</TableHead>
              <TableHead>GP</TableHead>
              <TableHead>G</TableHead>
              <TableHead>A</TableHead>
              <TableHead>PTS</TableHead>
              <TableHead>+/-</TableHead>
              <TableHead>PIM</TableHead>
              <TableHead>PPG</TableHead>
              <TableHead>SHG</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedPlayers.map((player, index) => (
              <TableRow key={player.id}>
                <TableCell>{index + 1}</TableCell>
                <TableCell className="font-medium">{player.name}</TableCell>
                <TableCell>{player.team}</TableCell>
                <TableCell>{player.position}</TableCell>
                <TableCell>{player.gp}</TableCell>
                <TableCell>{player.g}</TableCell>
                <TableCell>{player.a}</TableCell>
                <TableCell className="font-bold">{player.pts}</TableCell>
                <TableCell>{player.plusMinus}</TableCell>
                <TableCell>{player.pim}</TableCell>
                <TableCell>{player.ppg}</TableCell>
                <TableCell>{player.shg}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
