import { Table, TableBody, TableCaption, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

// This would be fetched from the API in a real implementation
const players = [
  {
    id: 1,
    name: "Cale Makar",
    team: "Colorado Avalanche",
    position: "RD",
    gp: 20,
    g: 8,
    a: 20,
    pts: 28,
    plusMinus: 15,
    pim: 6,
    hits: 25,
    blocks: 40,
  },
  {
    id: 2,
    name: "Roman Josi",
    team: "Nashville Predators",
    position: "LD",
    gp: 20,
    g: 6,
    a: 18,
    pts: 24,
    plusMinus: 8,
    pim: 8,
    hits: 30,
    blocks: 45,
  },
  {
    id: 3,
    name: "Victor Hedman",
    team: "Tampa Bay Lightning",
    position: "LD",
    gp: 19,
    g: 5,
    a: 18,
    pts: 23,
    plusMinus: 10,
    pim: 10,
    hits: 35,
    blocks: 50,
  },
  {
    id: 4,
    name: "Adam Fox",
    team: "New York Rangers",
    position: "RD",
    gp: 20,
    g: 4,
    a: 18,
    pts: 22,
    plusMinus: 12,
    pim: 4,
    hits: 20,
    blocks: 42,
  },
  {
    id: 5,
    name: "Quinn Hughes",
    team: "Vancouver Canucks",
    position: "LD",
    gp: 20,
    g: 3,
    a: 18,
    pts: 21,
    plusMinus: 6,
    pim: 6,
    hits: 15,
    blocks: 35,
  },
  {
    id: 6,
    name: "Miro Heiskanen",
    team: "Dallas Stars",
    position: "LD",
    gp: 19,
    g: 5,
    a: 15,
    pts: 20,
    plusMinus: 8,
    pim: 8,
    hits: 28,
    blocks: 48,
  },
  {
    id: 7,
    name: "Charlie McAvoy",
    team: "Boston Bruins",
    position: "RD",
    gp: 18,
    g: 4,
    a: 14,
    pts: 18,
    plusMinus: 14,
    pim: 12,
    hits: 45,
    blocks: 38,
  },
  {
    id: 8,
    name: "Dougie Hamilton",
    team: "New Jersey Devils",
    position: "RD",
    gp: 20,
    g: 7,
    a: 10,
    pts: 17,
    plusMinus: 5,
    pim: 14,
    hits: 32,
    blocks: 36,
  },
]

// Sort players by points
const sortedPlayers = [...players].sort((a, b) => b.pts - a.pts)

export default function DefenseStatsPage() {
  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-6">Defensive Statistics</h1>

      <div className="flex items-center space-x-2 mb-6">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input type="search" placeholder="Search players..." className="pl-8" />
        </div>
        <Button variant="outline">Filter</Button>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableCaption>NHL 25 League Defensive Statistics</TableCaption>
          <TableHeader>
            <TableRow>
              <TableHead>Rank</TableHead>
              <TableHead>Player</TableHead>
              <TableHead>Team</TableHead>
              <TableHead>Pos</TableHead>
              <TableHead>GP</TableHead>
              <TableHead>G</TableHead>
              <TableHead>A</TableHead>
              <TableHead>PTS</TableHead>
              <TableHead>+/-</TableHead>
              <TableHead>PIM</TableHead>
              <TableHead>HITS</TableHead>
              <TableHead>BLKS</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sortedPlayers.map((player, index) => (
              <TableRow key={player.id}>
                <TableCell>{index + 1}</TableCell>
                <TableCell className="font-medium">{player.name}</TableCell>
                <TableCell>{player.team}</TableCell>
                <TableCell>{player.position}</TableCell>
                <TableCell>{player.gp}</TableCell>
                <TableCell>{player.g}</TableCell>
                <TableCell>{player.a}</TableCell>
                <TableCell className="font-bold">{player.pts}</TableCell>
                <TableCell>{player.plusMinus}</TableCell>
                <TableCell>{player.pim}</TableCell>
                <TableCell>{player.hits}</TableCell>
                <TableCell>{player.blocks}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
