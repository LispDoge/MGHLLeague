"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { Trophy, BarChart3, UserPlus, LogIn, Menu, X, Users, User, LogOut } from "lucide-react"
import { useMobile } from "@/hooks/use-mobile"
import { useSession, signOut } from "next-auth/react"
import Image from "next/image"

export function Header() {
  const isMobile = useMobile()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const { data: session, status } = useSession()

  const isAdmin = session?.user?.role === "admin"
  const isTeamManager = ["admin", "owner", "gm"].includes(session?.user?.role as string)

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <Trophy className="h-6 w-6" />
            <span className="text-lg font-bold">NHL 25 League</span>
          </Link>
        </div>

        {isMobile ? (
          <>
            <Button variant="ghost" size="icon" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
            {isMenuOpen && (
              <div className="absolute top-16 left-0 right-0 bg-background border-b p-4 flex flex-col gap-2">
                <Link href="/standings" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                  <Trophy className="h-4 w-4" />
                  <span>Standings</span>
                </Link>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button
                      variant="ghost"
                      className="flex items-center gap-2 p-2 hover:bg-muted rounded-md w-full justify-start"
                    >
                      <BarChart3 className="h-4 w-4" />
                      <span>Statistics</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem asChild>
                      <Link href="/stats/offense">Offense Stats</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/stats/defense">Defense Stats</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/stats/goalie">Goalie Stats</Link>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <Link href="/teams" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                  <Users className="h-4 w-4" />
                  <span>Teams</span>
                </Link>

                {isAdmin && (
                  <Link href="/admin" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                    <User className="h-4 w-4" />
                    <span>Admin</span>
                  </Link>
                )}

                {isTeamManager && (
                  <Link href="/team-management" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                    <Users className="h-4 w-4" />
                    <span>Team Management</span>
                  </Link>
                )}

                {status === "authenticated" ? (
                  <>
                    <Link href="/dashboard" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                      <User className="h-4 w-4" />
                      <span>Dashboard</span>
                    </Link>
                    <Button
                      variant="ghost"
                      className="flex items-center gap-2 p-2 hover:bg-muted rounded-md w-full justify-start"
                      onClick={() => signOut({ callbackUrl: "/" })}
                    >
                      <LogOut className="h-4 w-4" />
                      <span>Sign Out</span>
                    </Button>
                  </>
                ) : (
                  <>
                    <Link href="/signup/season1" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                      <UserPlus className="h-4 w-4" />
                      <span>Season 1 Sign Up</span>
                    </Link>
                    <Link href="/login" className="flex items-center gap-2 p-2 hover:bg-muted rounded-md">
                      <LogIn className="h-4 w-4" />
                      <span>Login</span>
                    </Link>
                  </>
                )}
              </div>
            )}
          </>
        ) : (
          <nav className="flex items-center gap-6">
            <Link href="/standings" className="text-sm font-medium hover:underline underline-offset-4">
              Standings
            </Link>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="text-sm font-medium">
                  Statistics
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem asChild>
                  <Link href="/stats/offense">Offense Stats</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/stats/defense">Defense Stats</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/stats/goalie">Goalie Stats</Link>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Link href="/teams" className="text-sm font-medium hover:underline underline-offset-4">
              Teams
            </Link>

            {status === "authenticated" ? (
              <div className="flex items-center gap-2 ml-auto">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="rounded-full">
                      {session.user.image ? (
                        <Image
                          src={session.user.image || "/placeholder.svg"}
                          alt={session.user.name || "User"}
                          width={32}
                          height={32}
                          className="rounded-full"
                        />
                      ) : (
                        <User className="h-5 w-5" />
                      )}
                      <span className="sr-only">User menu</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem asChild>
                      <Link href="/dashboard">Dashboard</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/profile">Profile</Link>
                    </DropdownMenuItem>

                    {isAdmin && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link href="/admin">Admin Dashboard</Link>
                        </DropdownMenuItem>
                      </>
                    )}

                    {isTeamManager && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem asChild>
                          <Link href="/team-management">Team Management</Link>
                        </DropdownMenuItem>
                      </>
                    )}

                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => signOut({ callbackUrl: "/" })}>Sign Out</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ) : (
              <div className="flex items-center gap-2 ml-auto">
                <Link href="/signup/season1">
                  <Button variant="default" size="sm">
                    <UserPlus className="mr-2 h-4 w-4" /> Sign Up
                  </Button>
                </Link>
                <Link href="/login">
                  <Button variant="outline" size="sm">
                    <LogIn className="mr-2 h-4 w-4" /> Login
                  </Button>
                </Link>
              </div>
            )}
          </nav>
        )}
      </div>
    </header>
  )
}
