import Link from "next/link"
import { Trophy } from "lucide-react"

export function Footer() {
  return (
    <footer className="w-full border-t bg-background py-6">
      <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
        <div className="flex items-center gap-2">
          <Trophy className="h-5 w-5" />
          <span className="text-sm font-medium">NHL 25 League</span>
        </div>
        <nav className="flex gap-4 sm:gap-6">
          <Link href="/about" className="text-xs hover:underline underline-offset-4">
            About
          </Link>
          <Link href="/rules" className="text-xs hover:underline underline-offset-4">
            Rules
          </Link>
          <Link href="/contact" className="text-xs hover:underline underline-offset-4">
            Contact
          </Link>
          <Link href="/privacy" className="text-xs hover:underline underline-offset-4">
            Privacy
          </Link>
        </nav>
        <p className="text-xs text-muted-foreground">
          &copy; {new Date().getFullYear()} NHL 25 League. All rights reserved.
        </p>
      </div>
    </footer>
  )
}
