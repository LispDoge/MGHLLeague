#!/bin/bash
# Custom build script for Vercel

# Generate Prisma Client
echo "Generating Prisma Client..."
npx prisma generate

# Build Next.js application
echo "Building Next.js application..."
next build

echo "Build completed successfully!"
